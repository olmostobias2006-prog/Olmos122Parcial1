/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gremioaventurerosparcial;

/**
 * Aventurero con atributo de precision. Puede entrenar.
 */
public class Arquero extends Aventurero implements Entrenable {

    private final int precision;

    /**
     * Crea un arquero.
     *
     * @param codigo codigo de identificacion
     * @param nombre nombre
     * @param rango rango
     * @param precision puntos de precision (mayor que cero)
     * @throws IllegalArgumentException si algun dato es invalido
     */
    public Arquero(String codigo, String nombre, Rango rango, int precision) {
        super(codigo, nombre, rango);
        validarNumPositivo(precision, "precision del arquero");
        this.precision = precision;
    }

    public int getPrecision() {
        return precision;
    }

    @Override
    public String atacar() {
        return getNombre() + " dispara una flecha";
    }

    /**
     * @return precision * 3
     */
    @Override
    public int poderDeCombate() {
        return precision * 3;
    }

    @Override
    public String entrenar() {
        return getNombre() + " practica la punteria a larga distancia";
    }

    @Override
    public String toString() {
        return "Arquero {" + super.toString() + ", precision=" + precision + "}";
    }
}