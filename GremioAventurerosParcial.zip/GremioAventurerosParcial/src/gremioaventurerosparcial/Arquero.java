/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gremioaventurerosparcial;

/**
 * Aventurero con atributo de precision. Puede entrenar.
 */
public class Arquero extends Aventurero implements Entrenable {

    private final int precision;

    /**
     * Crea un arquero.
     *
     * @param codigo codigo de identificacion
     * @param nombre nombre
     * @param rango rango
     * @param precision puntos de precision (mayor que cero)
     * @throws IllegalArgumentException si algun dato es invalido
     */
    public Arquero(String codigo, String nombre, Rango rango, int precision) {
        super(codigo, nombre, rango);
        validarNumPositivo(precision, "precision del arquero");
        this.precision = precision;
    }

    /**
     * Devuelve la precision.
     *
     * @return puntos de precision
     */
    public int getPrecision() {
        return precision;
    }

    /**
     * Describe el ataque del arquero.
     *
     * @return texto del ataque
     */
    @Override
    public String atacar() {
        return getNombre() + " dispara una flecha";
    }

    /**
     * Calcula el poder de combate del arquero.
     *
     * @return precision multiplicada por 3
     */
    @Override
    public int poderDeCombate() {
        return precision * 3;
    }

    /**
     * Describe el entrenamiento del arquero.
     *
     * @return texto del entrenamiento
     */
    @Override
    public String entrenar() {
        return getNombre() + " practica la punteria a larga distancia";
    }

    /**
     * Devuelve los datos del arquero.
     *
     * @return texto con los datos comunes y la precision
     */
    @Override
    public String toString() {
        return "Arquero {" + super.toString() + ", precision=" + precision + "}";
    }
}