/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package gremioaventurerosparcial;


/**
 * Rango de un aventurero, de menor a mayor: BRONCE, PLATA y ORO.
 */
public enum Rango {
    BRONCE,
    PLATA,
    ORO
}