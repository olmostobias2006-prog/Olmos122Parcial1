package gremioaventurerosparcial;
import java.util.List;

/**
 * Programa principal del parcial: crea un gremio, registra aventureros y
 * muestra sus datos, ataques, entrenamientos y poderes de combate.
 */
public class GremioAventurerosParcial {

    /**
     * Metodo principal. Registra cinco aventureros (el ultimo esta repetido)
     * y muestra los resultados por consola.
     *
     * @param args argumentos de linea de comandos (no se usan)
     */
    public static void main(String[] args) {
        GremioAventureros gremio = new GremioAventureros("Guardianes de Eldoria");
        try {
            gremio.agregarAventurero(new Guerrero("G-01", "Arin", Rango.ORO, 30));
            gremio.agregarAventurero(new Mago("M-02", "Lyra", Rango.PLATA, 45));
            gremio.agregarAventurero(new Arquero("A-03", "Nox", Rango.BRONCE, 18));
            gremio.agregarAventurero(new Guerrero("G-04", "Borin", Rango.PLATA, 20));
            gremio.agregarAventurero(new Mago("G-01", "Arin", Rango.BRONCE, 99));
        } catch (AventureroRepetidoException e) {
            System.out.println(e.getMessage());
        }

        System.out.println("Aventureros registrados:");
        mostrarAventureros(gremio.obtenerAventureros());

        System.out.println("\nAtaques:");
        mostrarAtaques(gremio.obtenerAventureros());

        System.out.println("\nEntrenamientos:");
        mostrarEntrenamientos(gremio.obtenerAventureros());

        System.out.println("\nPoder de combate:");
        mostrarPoderes(gremio.obtenerAventureros());

        System.out.println("\nAventureros de rango PLATA:");
        mostrarAventureros(gremio.filtrarPorRango(Rango.PLATA));

        System.out.println("\nAventureros con poder >= 55:");
        mostrarAventureros(gremio.obtenerAventurerosPoderosos(55));
    }

    /**
     * Muestra los datos de cada aventurero de la lista.
     * Si la lista esta vacia, lo avisa por consola.
     *
     * @param aventureros lista de aventureros a mostrar
     */
    private static void mostrarAventureros(List<Aventurero> aventureros) {
        if (aventureros.isEmpty()) {
            System.out.println("Lista de aventureros vacia");
        }
        for (Aventurero av : aventureros) {
            System.out.println(av);
        }
    }

    /**
     * Muestra el ataque de cada aventurero de la lista.
     *
     * @param aventureros lista de aventureros
     */
    private static void mostrarAtaques(List<Aventurero> aventureros) {
        for (Aventurero av : aventureros) {
            System.out.println(av.atacar());
        }
    }

    /**
     * Muestra el entrenamiento de los aventureros que pueden entrenar.
     * Para los demas, indica que no tienen un entrenamiento especial.
     *
     * @param aventureros lista de aventureros
     */
    private static void mostrarEntrenamientos(List<Aventurero> aventureros) {
        for (Aventurero av : aventureros) {
            if (av instanceof Entrenable) {
                Entrenable ent = (Entrenable) av;
                System.out.println(ent.entrenar());
            } else {
                System.out.println(av.getNombre() + " no tiene un entrenamiento especial");
            }
        }
    }

    /**
     * Muestra el poder de combate de cada aventurero de la lista.
     *
     * @param aventureros lista de aventureros
     */
    private static void mostrarPoderes(List<Aventurero> aventureros) {
        for (Aventurero av : aventureros) {
            System.out.println(av.getNombre() + " " + av.poderDeCombate());
        }
    }
}