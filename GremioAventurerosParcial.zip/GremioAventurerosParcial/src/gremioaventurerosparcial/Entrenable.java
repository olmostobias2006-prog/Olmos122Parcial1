/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package gremioaventurerosparcial;

/**
 * Capacidad de tener un entrenamiento especial.
 */
public interface Entrenable {

    /**
     * @return texto con el entrenamiento especial
     */
    String entrenar();
}
