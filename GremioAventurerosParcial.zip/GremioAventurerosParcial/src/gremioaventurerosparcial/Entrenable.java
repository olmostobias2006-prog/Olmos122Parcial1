/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package gremioaventurerosparcial;

/**
 * Capacidad de tener un entrenamiento especial.
 * La implementan los aventureros que pueden entrenar (guerreros y arqueros).
 */
public interface Entrenable {

    /**
     * Describe el entrenamiento especial del aventurero.
     *
     * @return texto con el entrenamiento especial
     */
    String entrenar();
}