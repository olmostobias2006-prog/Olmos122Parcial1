/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gremioaventurerosparcial;

import java.util.ArrayList;
import java.util.List;

/**
 * Gremio que registra y administra a los aventureros.
 */
public class GremioAventureros {

    private final String nombre;
    private final List<Aventurero> aventureros;

    /**
     * Crea un gremio con un nombre.
     *
     * @param nombre nombre del gremio (no puede ser nulo ni estar en blanco)
     * @throws IllegalArgumentException si el nombre es nulo o esta en blanco
     */
    public GremioAventureros(String nombre) {
        if (nombre == null || nombre.trim().equals("")) {
            throw new IllegalArgumentException("El nombre del gremio no puede ser nulo ni estar en blanco");
        }
        this.nombre = nombre;
        aventureros = new ArrayList<>();
    }

    /**
     * Devuelve el nombre del gremio.
     *
     * @return nombre del gremio
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Registra un aventurero.
     *
     * @param aventurero aventurero a registrar (no puede ser nulo)
     * @throws AventureroRepetidoException si ya existe uno con el mismo codigo y nombre
     * @throws IllegalArgumentException si el aventurero es nulo
     */
    public void agregarAventurero(Aventurero aventurero) throws AventureroRepetidoException {
        if (aventurero == null) {
            throw new IllegalArgumentException("El aventurero no puede ser nulo");
        }
        if (aventureros.contains(aventurero)) {
            throw new AventureroRepetidoException(aventurero.getCodigo(), aventurero.getNombre());
        }
        aventureros.add(aventurero);
    }

    /**
     * Devuelve todos los aventureros registrados.
     *
     * @return una copia de la lista de aventureros
     */
    public List<Aventurero> obtenerAventureros() {
        return new ArrayList<>(aventureros);
    }

    /**
     * Devuelve los aventureros con poder de combate mayor o igual al recibido.
     *
     * @param poder poder minimo
     * @return lista de aventureros poderosos
     */
    public List<Aventurero> obtenerAventurerosPoderosos(int poder) {
        List<Aventurero> resultado = new ArrayList<>();
        for (Aventurero av : aventureros) {
            if (av.poderDeCombate() >= poder) {
                resultado.add(av);
            }
        }
        return resultado;
    }

    /**
     * Devuelve los aventureros de un rango.
     *
     * @param rango rango buscado
     * @return lista de aventureros con ese rango
     */
    public List<Aventurero> filtrarPorRango(Rango rango) {
        List<Aventurero> lista = new ArrayList<>();
        for (Aventurero av : aventureros) {
            if (av.getRango() == rango) {
                lista.add(av);
            }
        }
        return lista;
    }
}