/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Exception.java to edit this template
 */
package gremioaventurerosparcial;

/**
 * Excepcion que se lanza al intentar agregar al gremio un aventurero que ya
 * existe (mismo codigo y mismo nombre).
 */
public class AventureroRepetidoException extends Exception {

    /**
     * Crea la excepcion con un mensaje que indica el codigo y el nombre repetidos.
     *
     * @param codigo codigo del aventurero repetido
     * @param nombre nombre del aventurero repetido
     */
    public AventureroRepetidoException(String codigo, String nombre) {
        super("Ya existe un aventurero con el mismo codigo y nombre: " + codigo + ", " + nombre);
    }
}