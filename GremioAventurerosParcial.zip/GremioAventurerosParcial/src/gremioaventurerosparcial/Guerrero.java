/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gremioaventurerosparcial;
/**
 * Aventurero con atributo de fuerza. Puede entrenar.
 */
public class Guerrero extends Aventurero implements Entrenable {

    private final int fuerza;

    /**
     * Crea un guerrero.
     *
     * @param codigo codigo de identificacion
     * @param nombre nombre
     * @param rango rango
     * @param fuerza valor de la fuerza (mayor que cero)
     * @throws IllegalArgumentException si algun dato es invalido
     */
    public Guerrero(String codigo, String nombre, Rango rango, int fuerza) {
        super(codigo, nombre, rango);
        validarNumPositivo(fuerza, "fuerza del guerrero");
        this.fuerza = fuerza;
    }

    public int getFuerza() {
        return fuerza;
    }

    @Override
    public String atacar() {
        return getNombre() + " ataca con la espada";
    }

    /**
     * @return fuerza * 2
     */
    @Override
    public int poderDeCombate() {
        return fuerza * 2;
    }

    @Override
    public String entrenar() {
        return getNombre() + " practica combate cuerpo a cuerpo";
    }

    @Override
    public String toString() {
        return "Guerrero {" + super.toString() + ", fuerza=" + fuerza + "}";
    }
}