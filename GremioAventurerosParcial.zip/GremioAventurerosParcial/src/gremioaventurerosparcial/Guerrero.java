/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gremioaventurerosparcial;
/**
 * Aventurero con atributo de fuerza. Puede entrenar.
 */
public class Guerrero extends Aventurero implements Entrenable {

    private final int fuerza;

    /**
     * Crea un guerrero.
     *
     * @param codigo codigo de identificacion
     * @param nombre nombre
     * @param rango rango
     * @param fuerza valor de la fuerza (mayor que cero)
     * @throws IllegalArgumentException si algun dato es invalido
     */
    public Guerrero(String codigo, String nombre, Rango rango, int fuerza) {
        super(codigo, nombre, rango);
        validarNumPositivo(fuerza, "fuerza del guerrero");
        this.fuerza = fuerza;
    }

    /**
     * Devuelve la fuerza.
     *
     * @return valor de la fuerza
     */
    public int getFuerza() {
        return fuerza;
    }

    /**
     * Describe el ataque del guerrero.
     *
     * @return texto del ataque
     */
    @Override
    public String atacar() {
        return getNombre() + " ataca con la espada";
    }

    /**
     * Calcula el poder de combate del guerrero.
     *
     * @return fuerza multiplicada por 2
     */
    @Override
    public int poderDeCombate() {
        return fuerza * 2;
    }

    /**
     * Describe el entrenamiento del guerrero.
     *
     * @return texto del entrenamiento
     */
    @Override
    public String entrenar() {
        return getNombre() + " practica combate cuerpo a cuerpo";
    }

    /**
     * Devuelve los datos del guerrero.
     *
     * @return texto con los datos comunes y la fuerza
     */
    @Override
    public String toString() {
        return "Guerrero {" + super.toString() + ", fuerza=" + fuerza + "}";
    }
}