/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gremioaventurerosparcial;

/**
 * Aventurero con atributo de mana. No puede entrenar.
 */
public class Mago extends Aventurero {

    private final int mana;

    /**
     * Crea un mago.
     *
     * @param codigo codigo de identificacion
     * @param nombre nombre
     * @param rango rango
     * @param mana cantidad de mana (mayor que cero)
     * @throws IllegalArgumentException si algun dato es invalido
     */
    public Mago(String codigo, String nombre, Rango rango, int mana) {
        super(codigo, nombre, rango);
        validarNumPositivo(mana, "mana del mago");
        this.mana = mana;
    }

    public int getMana() {
        return mana;
    }

    @Override
    public String atacar() {
        return getNombre() + " lanza un hechizo";
    }

    /**
     * @return mana + 10
     */
    @Override
    public int poderDeCombate() {
        return mana + 10;
    }

    @Override
    public String toString() {
        return "Mago {" + super.toString() + ", mana=" + mana + "}";
    }
}