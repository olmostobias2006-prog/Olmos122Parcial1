/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gremioaventurerosparcial;

import java.util.Objects;

/**
 * Atributos y comportamiento que comparten todos los aventureros.
 * Se consideran iguales los aventureros con el mismo codigo y el mismo nombre,
 * sin importar su tipo, rango o caracteristicas particulares.
 */
public abstract class Aventurero {

    private final String codigo;
    private final String nombre;
    private final Rango rango;

    /**
     * Crea un aventurero validando sus datos.
     *
     * @param codigo codigo de identificacion (no puede ser nulo ni estar en blanco)
     * @param nombre nombre del aventurero (no puede ser nulo ni estar en blanco)
     * @param rango rango del aventurero (obligatorio)
     * @throws IllegalArgumentException si algun dato es invalido
     */
    public Aventurero(String codigo, String nombre, Rango rango) {
        validarTexto(codigo, "codigo");
        validarTexto(nombre, "nombre");
        if (rango == null) {
            throw new IllegalArgumentException("El rango es obligatorio");
        }
        this.codigo = codigo;
        this.nombre = nombre;
        this.rango = rango;
    }

    /**
     * Devuelve el codigo de identificacion.
     *
     * @return codigo del aventurero
     */
    public String getCodigo() {
        return codigo;
    }

    /**
     * Devuelve el nombre.
     *
     * @return nombre del aventurero
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Devuelve el rango.
     *
     * @return rango del aventurero
     */
    public Rango getRango() {
        return rango;
    }

    /**
     * Calcula el poder de combate, que depende del tipo de aventurero.
     *
     * @return poder de combate
     */
    public abstract int poderDeCombate();

    /**
     * Describe el ataque del aventurero.
     *
     * @return texto del ataque
     */
    public abstract String atacar();

    /**
     * Valida que el texto no sea nulo ni este en blanco.
     *
     * @param palabra texto a validar
     * @param campo nombre del campo que se valida
     * @throws IllegalArgumentException si el texto es nulo o esta en blanco
     */
    protected static void validarTexto(String palabra, String campo) {
        if (palabra == null || palabra.trim().equals("")) {
            throw new IllegalArgumentException("El campo " + campo + " no puede ser null ni estar en blanco");
        }
    }

    /**
     * Valida que el numero sea mayor que cero.
     *
     * @param num numero a validar
     * @param campo nombre del campo que se valida
     * @throws IllegalArgumentException si el numero es menor o igual a cero
     */
    protected static void validarNumPositivo(int num, String campo) {
        if (num <= 0) {
            throw new IllegalArgumentException("El valor de " + campo + " no puede ser menor o igual a cero");
        }
    }

    /**
     * Compara dos aventureros por codigo y nombre.
     *
     * @param obj objeto a comparar
     * @return true si es un aventurero con el mismo codigo y el mismo nombre
     */
    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Aventurero otro) {
            return codigo.equals(otro.codigo) && nombre.equals(otro.nombre);
        }
        return false;
    }

     /**
     * Calcula el hash del aventurero usando los mismos atributos que equals
     * (codigo y nombre), para respetar que dos aventureros iguales tengan el mismo hash.
     *
     * @return hash calculado con el codigo y el nombre
     */
    @Override
    public int hashCode() {
        return Objects.hash(codigo, nombre);
    }

    /**
     * Devuelve los datos comunes de todos los aventureros.
     * Las subclases lo reutilizan con super.toString().
     *
     * @return texto con codigo, nombre y rango
     */
    @Override
    public String toString() {
        return "codigo=" + codigo + ", nombre=" + nombre + ", rango=" + rango;
    }
}