/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gremioaventurerosparcial;

/**
 * Atributos y comportamiento que comparten todos los aventureros.
 * Se consideran iguales los aventureros con el mismo codigo y el mismo nombre.
 */
public abstract class Aventurero {

    private final String codigo;
    private final String nombre;
    private final Rango rango;

    /**
     * Crea un aventurero validando sus datos.
     *
     * @param codigo codigo de identificacion (no puede ser nulo ni estar en blanco)
     * @param nombre nombre del aventurero (no puede ser nulo ni estar en blanco)
     * @param rango rango del aventurero (obligatorio)
     * @throws IllegalArgumentException si algun dato es invalido
     */
    public Aventurero(String codigo, String nombre, Rango rango) {
        validarTexto(codigo, "codigo");
        validarTexto(nombre, "nombre");
        if (rango == null) {
            throw new IllegalArgumentException("El rango es obligatorio");
        }
        this.codigo = codigo;
        this.nombre = nombre;
        this.rango = rango;
    }

    public String getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public Rango getRango() {
        return rango;
    }

    /**
     * Calcula el poder de combate, que depende del tipo de aventurero.
     *
     * @return poder de combate
     */
    public abstract int poderDeCombate();

    /**
     * Describe el ataque del aventurero.
     *
     * @return texto del ataque
     */
    public abstract String atacar();

    /**
     * Valida que el texto no sea nulo ni este en blanco.
     *
     * @param palabra texto a validar
     * @param campo nombre del campo que se valida
     * @throws IllegalArgumentException si el texto es nulo o esta en blanco
     */
    protected static void validarTexto(String palabra, String campo) {
        if (palabra == null || palabra.trim().equals("")) {
            throw new IllegalArgumentException("El campo " + campo + " no puede ser null ni estar en blanco");
        }
    }

    /**
     * Valida que el numero sea mayor que cero.
     *
     * @param num numero a validar
     * @param campo nombre del campo que se valida
     * @throws IllegalArgumentException si el numero es menor o igual a cero
     */
    protected static void validarNumPositivo(int num, String campo) {
        if (num <= 0) {
            throw new IllegalArgumentException("El valor de " + campo + " no puede ser menor o igual a cero");
        }
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Aventurero) {
            Aventurero otro = (Aventurero) obj;
            return codigo.equals(otro.codigo) && nombre.equals(otro.nombre);
        }
        return false;
    }

    @Override
    public String toString() {
        return "codigo=" + codigo + ", nombre=" + nombre + ", rango=" + rango;
    }
}